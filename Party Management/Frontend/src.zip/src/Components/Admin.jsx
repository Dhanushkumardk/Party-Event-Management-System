import "../assets/Admin.css"; // Make sure to adjust the path based on your project structure
import ViewEvents from "../Components/ViewEvents"
import "../assets/Delete.css"
import "../assets/Form.css"
const Admin = () => {
 

  return (
    <div>
        
      <div className="admin-body">
        <ViewEvents/>
       
    </div>
    </div>
  );
};

export default Admin;
